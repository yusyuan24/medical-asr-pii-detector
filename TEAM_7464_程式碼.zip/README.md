# AICUP2025_TEAM_7464

本專案為 AICUP 2025 醫病語音個資辨識競賽提交程式碼，實作中英文語音轉文字（ASR）與語音個資命名實體辨識（PHI NER）任務。

## 環境配置與安裝
Python 3.11
CUDA 11.8 
cuDNN 8.6